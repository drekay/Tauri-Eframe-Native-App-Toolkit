// src/core/mod.rs
pub mod plugin_system;
pub use plugin_system::PluginSystem;

// Add other module declarations as needed
pub mod message_bus;
pub mod app;