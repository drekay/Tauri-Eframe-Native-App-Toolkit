mod core;

//use core::app::TauriEframeNativeApp;

fn main() -> Result<(), eframe::Error> {
    Ok(())

   // TauriEframeNativeApp::run()
}