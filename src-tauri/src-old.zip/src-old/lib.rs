// lib.rs

use crossbeam_channel::{Sender, Receiver};
use eframe::egui;

pub mod core;
pub mod plugins;
pub mod ui;

// Re-export commonly used items
pub use core::app::TauriEframeNativeApp;

//pub use plugins::window_management::window_plugin::{Plugin, UIPlugin, Message};
pub use plugins::window_management::{WindowPlugin, WindowControllerPlugin};
//pub use plugins::ui_controller_plugin::UiControllerPlugin;

// Define or re-export common types and traits
#[derive(Debug, Clone)]
pub enum Message {
  Broadcast(String),
  WindowPlugin(WindowPluginMessage),
  WindowControllerPlugin(WindowControllerPluginMessage),
  // Add more plugin-specific message types as needed
}

#[derive(Debug, Clone)]
pub enum WindowPluginMessage {
  AddWindow,
  CollapseWindow(usize),
  DragWindowStart(usize, (f32, f32)),
  DragWindowMove((f32, f32)),
  MinimizeWindow(usize),
  DragWindowEnd,
  ConfirmedCloseWindow(usize),
}

#[derive(Debug, Clone)]
pub enum WindowControllerPluginMessage {
  CloseWindow(usize),
}

pub trait Plugin: Send {
    fn update(&mut self, ctx: &egui::Context, rx: &Receiver<Message>, tx: &Sender<Message>);
    fn name(&self) -> &str;
}

pub trait UIPlugin: Plugin {
  fn update_ui(&mut self, ctx: &egui::Context);
}