#!/bin/bash

# Change to the src directory
cd src

# Find all mod.rs files, print their paths, and their contents
find . -name "mod.rs" -type f | while read -r file; do
    echo "$file"
    echo "----------------------------------------"
    cat "$file"
    echo "----------------------------------------"
    echo  # Print an empty line for better readability
done


./path/to/mod.rs
----------------------------------------
File contents here or nothing here if blank
----------------------------------------