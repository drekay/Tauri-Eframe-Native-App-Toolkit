//src/sys_plugins/mod.rs
use crossbeam_channel::{Sender, Receiver};
use eframe::egui;

pub mod ui_controller_plugin;
pub mod window_management;

