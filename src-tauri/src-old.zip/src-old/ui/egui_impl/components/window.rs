// src/ui/egui_impl/components/window.rs

use eframe::egui;

use super::Frame;

pub struct Window {
    pub frame: Frame,
    pub id: usize,
    pub position: egui::Pos2,
    pub size: egui::Vec2,
    pub is_open: bool,
}

impl Window {
    pub fn new(id: usize, title: &str, position: egui::Pos2, size: egui::Vec2) -> Self {
        Self {
            frame: Frame::new(title),
            id,
            position,
            size,
            is_open: true,
        }
    }

    pub fn show(&mut self, ui: &mut egui::Ui) -> bool {
        if !self.is_open {
            return false;
        }

        let window = egui::Window::new(&self.frame.title)
            .id(egui::Id::new(self.id))
            .default_pos(self.position)
            .default_size(self.size)
            .resizable(true)
            .collapsible(true);

        let mut is_open = self.is_open;
        window.show(ui.ctx(), |ui| {
            let (response, is_closed, drag_started, drag_released, _, drag_delta) = self.frame.show(ui, self.id);
            
            if is_closed {
                is_open = false;
            }

            /*if drag_started {
                ui.output().cursor_icon = egui::CursorIcon::Grabbing;
            }

            if drag_released {
                ui.output().cursor_icon = egui::CursorIcon::Default;
            }*/

            self.position += drag_delta;
        });

        self.is_open = is_open;
        is_open
    }

    pub fn set_content(&mut self, content: String) {
        self.frame.content = content;
    }

    pub fn is_open(&self) -> bool {
        self.is_open
    }

    pub fn close(&mut self) {
        self.is_open = false;
    }

    pub fn open(&mut self) {
        self.is_open = true;
    }

    pub fn toggle(&mut self) {
        self.is_open = !self.is_open;
    }
}

//2. You might want to create a trait in components/window.rs that defines common behavior for all windows, which each specific window type can implement.
//3. The WindowPlugin and WindowControllerPlugin can then work with these window types, managing their creation, destruction, and overall lifecycle.